jQuery(document).ready(function ($) {
    let productID = $('#product_id_field').val(); // Add this field in the template for the product ID

    $.ajax({
        url: ajaxurl,
        type: 'POST',
        data: {
            action: 'get_average_rating',
            product_id: productID,
        },
        success: function (response) {
            let data = JSON.parse(response);
            $('#average_rating_display').html('Average Rating: ' + data.average);
        },
    });
});